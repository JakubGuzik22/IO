package fooapp.foo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FooComponent {

    public FooComponent(String foo) {log.info("constructing foo component using string", foo);}
}
