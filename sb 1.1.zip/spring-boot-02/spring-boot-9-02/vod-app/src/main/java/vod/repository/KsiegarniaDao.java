package vod.repository;

import vod.model.Ksiegarnia;
import vod.model.Ksiazka;

import java.util.List;

public interface KsiegarniaDao {

    List<Ksiegarnia> findAll();

    Ksiegarnia findById(int id);

    List<Ksiegarnia> findByKsiazka(Ksiazka m);

}
