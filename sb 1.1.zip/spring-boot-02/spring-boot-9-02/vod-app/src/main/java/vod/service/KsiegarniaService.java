package vod.service;

import vod.model.Ksiazka;
import vod.model.Ksiegarnia;

import java.util.List;

public interface KsiegarniaService {

    Ksiegarnia getKsiegarniaById(int id);

    List<Ksiegarnia> getAllKsiegarnie();

    List<Ksiegarnia> getKsiegarnieByKsiazka(Ksiazka ksiazka);

    List<Ksiazka> getKsiazkiByKsiegarnia(Ksiegarnia ksiegarnia);
}