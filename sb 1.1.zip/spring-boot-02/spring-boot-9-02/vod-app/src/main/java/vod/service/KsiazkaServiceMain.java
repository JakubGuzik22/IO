package vod.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import vod.repository.KsiegarniaDao;
import vod.repository.KsiazkaDao;
import vod.repository.mem.MemKsiegarniaDao;
import vod.repository.mem.MemKsiazkaDao;
import vod.model.Ksiegarnia;
import vod.service.impl.KsiegarniaServiceBean;

import java.util.List;

public class KsiazkaServiceMain {

    public static void main(String[] args) {
        System.out.println("Let's find ksiegarnie!");


        ApplicationContext context = new AnnotationConfigApplicationContext("vod");
        KsiegarniaService service = context.getBean(KsiegarniaService.class);

//        KsiegarniaDao ksiegarniaDao = new MemKsiegarniaDao();
//        KsiazkaDao ksiazkaDao = new MemKsiazkaDao();
//
//        KsiegarniaService service2 = new KsiegarniaServiceBean(ksiegarniaDao, ksiazkaDao);

        List<Ksiegarnia> ksiegarnie = service.getAllKsiegarnie();
        System.out.println(ksiegarnie.size() + " ksiegarnie found:");
        ksiegarnie.forEach(System.out::println);
    }
}
