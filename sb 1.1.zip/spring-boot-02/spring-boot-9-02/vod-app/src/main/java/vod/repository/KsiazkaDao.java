package vod.repository;

import vod.model.Autor;
import vod.model.Ksiegarnia;
import vod.model.Ksiazka;

import java.util.List;

public interface KsiazkaDao {

    // zwraca wszystkie ksiazki
    List<Ksiazka> findAll();

    // znajdź ksiazke po id
    Ksiazka findById(int id);

    // znajdź ksiazki konkretnego autora
    List<Ksiazka> findByAutor(Autor autor);

    // znajdź ksiazki dostępne w danej księgarni
    List<Ksiazka> findByKsiegarnia(Ksiegarnia ksiegarnia);

    // dodaj nową ksiazke
    Ksiazka add(Ksiazka ksiazka);
}