package vod.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vod.model.Ksiazka;
import vod.model.Ksiegarnia;
import vod.repository.KsiegarniaDao;
import vod.repository.KsiazkaDao;
import vod.service.KsiegarniaService;

import java.util.List;
import java.util.logging.Logger;

@Component
public class KsiegarniaServiceBean implements KsiegarniaService {

    private static final Logger log = Logger.getLogger(KsiegarniaService.class.getName());

    private KsiegarniaDao ksiegarniaDao;

    private KsiazkaDao ksiazkaDao;

    public KsiegarniaServiceBean(KsiegarniaDao ksiegarniaDao, KsiazkaDao ksiazkaDao) {
        log.info("creating ksiegarnia service bean");
        this.ksiegarniaDao = ksiegarniaDao;
        this.ksiazkaDao = ksiazkaDao;
    }

@Override
    public Ksiegarnia getKsiegarniaById(int id) {
        log.info("searching ksiegarnia by id " + id);
        return ksiegarniaDao.findById(id);
    }

    @Override
    public List<Ksiazka> getKsiazkiByKsiegarnia(Ksiegarnia k) {
        log.info("searching ksiazki in ksiegarnia " + k.getId());
        return ksiazkaDao.findByKsiegarnia(k);
    }

    @Override
    public List<Ksiegarnia> getAllKsiegarnie() {
        log.info("searching all ksiegarnie");
        return ksiegarniaDao.findAll();
    }
    @Override
    public List<Ksiegarnia> getKsiegarnieByKsiazka(Ksiazka ksiazka) {
        log.info("searching ksiegarnie by ksiazka " + ksiazka.getId());
        return ksiegarniaDao.findByKsiazka(ksiazka);
    }

}