package vod.service;

import vod.model.Autor;
import vod.model.Ksiazka;
import vod.model.Ksiegarnia;

import java.util.List;

public interface KsiazkaService {

    List<Ksiazka> getAllKsiazki();

    List<Ksiazka> getKsiazkiByAutor(Autor autor);

    List<Ksiazka> getKsiazkiByKsiegarnia(Ksiegarnia ksiegarnia);

    Ksiazka getKsiazkaById(int id);

    List<Autor> getAllAutorzy();

    Autor getAutorById(int id);
}