package vod.repository.mem;

import vod.model.Ksiazka;
import vod.model.Ksiegarnia;
import vod.repository.KsiegarniaDao;

import java.util.List;
import java.util.stream.Collectors;

public class MemKsiegarniaDao implements KsiegarniaDao {

    @Override
    public List<Ksiegarnia> findAll() {
        return SampleData.ksiegarnie;
    }

    @Override
    public Ksiegarnia findById(int id) {
        return SampleData.ksiegarnie.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Ksiegarnia> findByKsiazka(Ksiazka m) {
        return SampleData.ksiegarnie.stream().filter(c -> c.getKsiazki().contains(m)).collect(Collectors.toList());
    }
}
