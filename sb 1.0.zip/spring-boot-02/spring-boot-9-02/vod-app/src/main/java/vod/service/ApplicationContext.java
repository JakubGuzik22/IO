package vod.service;

public interface ApplicationContext {
}
